#ifndef __BEEP_H__
#define __BEEP_H__
 

void BEEP_Init(void);
 
#define BEEP PFout(8)
 
#endif /*__BEEP_H__*/\
